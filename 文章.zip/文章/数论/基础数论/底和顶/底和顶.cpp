#include <bits/stdc++.h>

using namespace std;

const double e = 2.718281828459045, EPS = 1e-6;

int myFloor(double x)
{
    return floor(x + EPS);
}

int myCeil(double x)
{
    return ceil(x - EPS);
}

double equal(double x, double y)
{
    if (fabs(x - y) < EPS) {
        return 1;
    }
    return 0;
}

double isNotInterger(double x)
{
    if (fmod(fabs(x), 1) < EPS || fmod(fabs(x), 1) > 1 - EPS) {
        return 0;
    }
    return 1;
}

signed main()
{
    assert(floor(e) == 2);
    assert(floor(-e) == -3);
    assert(ceil(e) == 3);
    assert(ceil(-e) == -2);
    for (int x = -1000; x <= 1000; ++x) {
        assert(myFloor(x + 0.5) == x);
    }
    for (int x = -1000; x <= 1000; ++x) {
        assert(myCeil(x + 0.5) == x + 1);
    }
    
    for (int x = -1000; x <= 1000; ++x) {
        assert(x - 1 < myFloor(x));
        assert(myFloor(x) <= x);
        assert(x <= myCeil(x));
        assert(myCeil(x) < x + 1);
    }
    
    for (double x = -1000; x <= 1000; x += 0.01) {
        assert(equal(myCeil(x - 1e-6) - myFloor(x + 1e-6), isNotInterger(x)));
    }

    for (double x = -1000; x <= 1000; x += 0.01) {
        assert(myFloor(-x) == -myCeil(x));
    }
    for (double x = -1000; x <= 1000; x += 0.01) {
        assert(myCeil(-x) == -myFloor(x));
    }

    for (double x = -1000; x <= 1000; x += 0.01) {
        int n = myFloor(x);
        assert(n <= x + EPS && x < n + 1 + EPS);
    }
    for (double x = -1000; x <= 1000; x += 0.01) {
        int n = myFloor(x);
        assert(x - 1 < n + EPS && n <= x + EPS);
    }
    for (double x = -1000; x <= 1000; x += 0.01) {
        int n = myCeil(x);
        assert(n - 1 < x + EPS && x <= n + EPS);
    }
    for (double x = -1000; x <= 1000; x += 0.01) {
        int n = myCeil(x);
        assert(x <= n + EPS && n < x + 1 + EPS);
    }

    for (double x = -100; x <= 10; x += 0.01) {
        for (int n = -100; n <= 100; ++n) {
            assert(myFloor(x + n) == myFloor(x) + n);
        }
    }
    for (double x = -100; x <= 10; x += 0.01) {
        for (int n = -100; n <= 100; ++n) {
            assert(myCeil(x + n) == myCeil(x) + n);
        }
    }
    puts("OK");
    return 0;
}